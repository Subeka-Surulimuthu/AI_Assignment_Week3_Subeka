// Utility module: generate random test data for common fields and format for prompts

const firstNames = ["Alex", "Sam", "Jordan", "Taylor", "Casey", "Riley", "Morgan", "Jamie", "Robin", "Avery"];
const lastNames = ["Smith", "Johnson", "Brown", "Davis", "Miller", "Wilson", "Moore", "Taylor", "Anderson", "Thomas"];

function randInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function randomString(length = 8) {
  const chars = "abcdefghijklmnopqrstuvwxyz";
  let s = "";
  for (let i = 0; i < length; i++) s += chars.charAt(Math.floor(Math.random() * chars.length));
  return s;
}

export function generateTestDataFromFields(fields = []) {
  const data = {};
  // simple heuristics based on field name
  for (const f of fields) {
    const key = f.toString();
    const lk = key.toLowerCase();
    if (lk.includes("first") || lk.includes("fname")) {
      data[key] = firstNames[randInt(0, firstNames.length - 1)];
    } else if (lk.includes("last") || lk.includes("lname") || lk.includes("surname")) {
      data[key] = lastNames[randInt(0, lastNames.length - 1)];
    } else if (lk.includes("email")) {
      const fn = firstNames[randInt(0, firstNames.length - 1)].toLowerCase();
      const ln = lastNames[randInt(0, lastNames.length - 1)].toLowerCase();
      data[key] = `${fn}.${ln}${randInt(1,99)}@example.com`;
    } else if (lk.includes("phone") || lk.includes("mobile") || lk.includes("tel")) {
      data[key] = `+1${randInt(200,999)}${randInt(200,999)}${randInt(1000,9999)}`;
    } else if (lk.includes("address") || lk.includes("addr")) {
      data[key] = `${randInt(1,9999)} ${randomString(6)} St`;
    } else if (lk.includes("zip") || lk.includes("postal")) {
      data[key] = `${randInt(10000,99999)}`;
    } else if (lk.includes("password") || lk.includes("pwd")) {
      data[key] = `P@${randomString(6)}${randInt(10,99)}`;
    } else if (lk.includes("count") || lk.includes("qty") || lk.includes("number") || lk.includes("age")) {
      data[key] = `${randInt(1,100)}`;
    } else {
      // default to a readable string
      data[key] = `${firstNames[randInt(0, firstNames.length - 1)]}${randInt(1,999)}`;
    }
  }
  return data;
}

export function formatTestDataForPrompt(data = {}) {
  // returns a plain text block that can be appended to the chat/prompt input
  const parts = [];
  for (const k of Object.keys(data)) {
    const v = data[k];
    // if value looks numeric don't quote
    const val = /^[0-9+\-]/.test(String(v)) ? v : `'${v}'`;
    parts.push(`${k}: ${val}`);
  }
  return parts.join(", ");
}

// New helper: accept a pageModel (common shapes) and produce test data for every detected field
export function generateTestDataForPageModel(pageModel) {
  // pageModel may be:
  // - an array of field names: ["firstName","lastName"...]
  // - an object with .fields: [{ name: 'firstName', type: 'text' }, ...]
  // - a map/object: { firstName: {...}, lastName: {...} }
  let fields = [];
  if (!pageModel) return generateTestDataFromFields([]);

  if (Array.isArray(pageModel)) {
    // array may contain strings or objects with name
    fields = pageModel.map(f => (typeof f === "string" ? f : (f.name || JSON.stringify(f))));
  } else if (pageModel.fields && Array.isArray(pageModel.fields)) {
    fields = pageModel.fields.map(f => (typeof f === "string" ? f : (f.name || JSON.stringify(f))));
  } else if (typeof pageModel === "object") {
    // treat keys as field names
    fields = Object.keys(pageModel);
  }

  return generateTestDataFromFields(fields);
}

// New: code generator types and template generator for Playwright + TypeScript page object
export const CODE_GENERATOR_TYPES = {
  FEATURE: 'FEATURE',
  PAGE: 'PAGE',
  TESTDATA: 'TESTDATA',
  PLAYWRIGHT_TS_PAGE: 'PLAYWRIGHT_TS_PAGE'
};

/**
 * Return a code-generation prompt/template string for a given generator type.
 * options may contain { className, selectors } etc.
 */
export function getCodeGeneratorPrompt(type, options = {}) {
  const className = options.className || 'MyPage';
  const selectors = options.selectors || [{ name: 'submitButton', selector: 'button#submit' }];

  if (type === CODE_GENERATOR_TYPES.PLAYWRIGHT_TS_PAGE || type === 'PLAYWRIGHT_TS_PAGE') {
    const selectorComments = selectors.map(s => `// ${s.name}: ${s.selector}`).join('\n');
    return `// Playwright TypeScript Page Object for ${className}
import { Page } from 'playwright';

export class ${className} {
  private page: Page;

  constructor(page: Page) {
    this.page = page;
  }

  async goto(url: string) {
    await this.page.goto(url);
  }

  async click(selector: string) {
    await this.page.click(selector);
  }

  async fill(selector: string, value: string) {
    await this.page.fill(selector, value);
  }

  // Example custom methods using selectors
  async clickSubmit() {
    await this.page.click('${selectors[0].selector}');
  }

  async submitForm(data: { [key: string]: string }) {
    // implement filling logic using selectors
    // e.g. await this.fill('input[name=\"firstName\"]', data.firstName);
  }
}

${selectorComments}
`;
  }

  // default fallback (empty)
  return '';
}

// attach helper to window for non-module consumers
window.promptUtils = window.promptUtils || {};
window.promptUtils.generateTestDataFromFields = generateTestDataFromFields;
window.promptUtils.formatTestDataForPrompt = formatTestDataForPrompt;
window.promptUtils.generateTestDataForPageModel = generateTestDataForPageModel;
window.promptUtils.getCodeGeneratorPrompt = getCodeGeneratorPrompt;
