// ...new file...
import { generateTestDataFromFields, formatTestDataForPrompt, generateTestDataForPageModel } from './prompt.js';

const defaultFields = ["firstName", "lastName", "email", "phone", "address"];

// Try to discover page model / collected fields from common locations
function discoverPageModelFields() {
  // 1. well-known global
  if (window.pageModel) {
    return pageModelToFieldNames(window.pageModel);
  }
  // 2. alternate global names
  if (window.__pageModel) {
    return pageModelToFieldNames(window.__pageModel);
  }
  if (window.collectedFields) {
    return Array.isArray(window.collectedFields) ? window.collectedFields : Object.keys(window.collectedFields || {});
  }
  // 3. localStorage (some inspectors persist)
  try {
    const stored = localStorage.getItem('pageModel') || localStorage.getItem('collectedFields') || localStorage.getItem('pageFields');
    if (stored) {
      const parsed = JSON.parse(stored);
      return pageModelToFieldNames(parsed);
    }
  } catch (e) {
    // ignore parse errors
  }
  // fallback
  return defaultFields;
}

function pageModelToFieldNames(model) {
  if (!model) return defaultFields;
  if (Array.isArray(model)) {
    return model.map(m => (typeof m === "string" ? m : (m.name || m.field || m.id || JSON.stringify(m))));
  }
  if (model.fields && Array.isArray(model.fields)) {
    return model.fields.map(f => (typeof f === "string" ? f : (f.name || f.field || f.id || JSON.stringify(f))));
  }
  if (typeof model === "object") {
    return Object.keys(model);
  }
  return defaultFields;
}

function insertTestDataIntoChatInput(dataObj) {
  const chatInput = document.getElementById("chatInput");
  if (!chatInput) return;
  const formatted = formatTestDataForPrompt(dataObj);

  // Insert as a clear block. Use JSON block if more appropriate for downstream parsing.
  const jsonBlock = JSON.stringify(dataObj, null, 2);
  const block = `Test Data (JSON):\n${jsonBlock}\n\nTest Data (KV): ${formatted}`;

  // If user already provided text, append the test data block, else set it
  if (chatInput.value && chatInput.value.trim().length > 0) {
    // avoid double-appending same JSON block
    if (!chatInput.value.includes("Test Data (JSON):")) {
      chatInput.value = `${chatInput.value.trim()}\n\n${block}`;
    }
  } else {
    chatInput.value = block;
  }
}

function generateAndInsert(fields = defaultFields) {
  const data = generateTestDataFromFields(fields);
  insertTestDataIntoChatInput(data);
  return data;
}

function generateFromPageModelAndInsert() {
  const discovered = discoverPageModelFields();
  // If a pageModel object exists and promptUtils.generateTestDataForPageModel is available, prefer that
  let data;
  if (window.promptUtils && window.promptUtils.generateTestDataForPageModel && (window.pageModel || window.__pageModel)) {
    data = window.promptUtils.generateTestDataForPageModel(window.pageModel || window.__pageModel);
    // if that returns empty, fallback to field names processing
    if (!data || Object.keys(data).length === 0) {
      data = generateTestDataFromFields(discovered);
    }
  } else {
    data = generateTestDataFromFields(discovered);
  }
  insertTestDataIntoChatInput(data);
  return data;
}

function setup() {
  const toggle = document.getElementById("javaGenModeTestData"); // checkbox added in panel.html
  const refresh = document.getElementById("testDataRefresh");
  const sendBtn = document.getElementById("sendMessage");

  if (toggle) {
    toggle.addEventListener("change", () => {
      if (toggle.checked) {
        // generate test data immediately using discovered fields
        generateFromPageModelAndInsert();
      }
      // if unchecked, do nothing (leave input as-is)
    });
  }

  if (refresh) {
    refresh.addEventListener("click", (e) => {
      e.preventDefault();
      // only regenerate if toggle is on
      if (toggle && toggle.checked) {
        generateFromPageModelAndInsert();
      } else {
        // if toggle off, still allow one-off regen using discovered fields
        generateFromPageModelAndInsert();
      }
    });
  }

  // ensure test data present before the chat generation runs
  // this listener will ensure test data gets added if the Test Data mode is selected
  if (sendBtn) {
    sendBtn.addEventListener("click", () => {
      const testModeOn = toggle && toggle.checked;
      if (testModeOn) {
        const chatInput = document.getElementById("chatInput");
        const hasTestData = chatInput && /Test Data \(JSON\):/i.test(chatInput.value || "");
        if (!hasTestData) {
          generateFromPageModelAndInsert();
        }
      }
    }, { capture: true });
  }
}

// Defer setup until DOM ready
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", setup);
} else {
  setup();
}
