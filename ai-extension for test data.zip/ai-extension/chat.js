function getPromptKeyForSelection({ engine, language, otherOptions /* ... */ }) {
	// Playwright + TypeScript specific handling
	if (engine === 'playwright' && language === 'typescript') {
		return 'PLAYWRIGHT_PAGE_TS';
	}

	// Default prompt key selection logic
	return 'PLAYWRIGHT_PAGE';
}