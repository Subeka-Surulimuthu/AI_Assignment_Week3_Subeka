const CODE_GENERATOR_TYPES = {
	// Add Playwright Page (TypeScript) generator prompt
	PLAYWRIGHT_PAGE_TS: {
		name: 'Playwright Page (TypeScript)',
		prompt: `You are a code generator for Playwright using TypeScript. Generate code that uses Playwright's Page object and async/await.
- Use TypeScript types (import { Page } from '@playwright/test' or from 'playwright' as appropriate).
- Provide an exported async function like: export async function run(page: Page) { /* steps */ }
- Use page.goto, page.locator(...).click(), page.locator(...).fill(), and await where necessary.
- Prefer locator over page.$ selectors, and use await page.waitForLoadState('networkidle') or appropriate waits when needed.
- Keep code concise, include necessary imports, and avoid wrapping in unnecessary classes.
- If the user prompt references selectors or credentials, inject them as variables or parameters and avoid hardcoding secrets.`,
	},typescript
};

const CODE_GENERATOR_TYPES_OLD = {
	// Add Playwright Page (TypeScript) generator prompt
	PLAYWRIGHT_PAGE_TS: {
		name: 'Playwright Page (TypeScript)',
		prompt: `You are a code generator for Playwright using TypeScript. Generate code that uses Playwright's Page object and async/await.
- Use TypeScript types (import { Page } from '@playwright/test' or from 'playwright' as appropriate).
- Provide an exported async function like: export async function run(page: Page) { /* steps */ }
- Use page.goto, page.locator(...).click(), page.locator(...).fill(), and await where necessary.
- Prefer locator over page.$ selectors, and use await page.waitForLoadState('networkidle') or appropriate waits when needed.
- Keep code concise, include necessary imports, and avoid wrapping in unnecessary classes.
- If the user prompt references selectors or credentials, inject them as variables or parameters and avoid hardcoding secrets.`,
	},
};

const CODE_GENERATOR_TYPES_NEW = {
	// Add Playwright Page (TypeScript) generator prompt
	PLAYWRIGHT_PAGE_TS: {
		name: 'Playwright Page (TypeScript)',
		prompt: `You are a code generator for Playwright using TypeScript. Generate code that uses Playwright's Page object and async/await.
- Use TypeScript types (import { Page } from '@playwright/test' or from 'playwright' as appropriate).
- Provide an exported async function like: export async function run(page: Page) { /* steps */ }
- Use page.goto, page.locator(...).click(), page.locator(...).fill(), and await where necessary.
- Prefer locator over page.$ selectors, and use await page.waitForLoadState('networkidle') or appropriate waits when needed.
- Keep code concise, include necessary imports, and avoid wrapping in unnecessary classes.
- If the user prompt references selectors or credentials, inject them as variables or parameters and avoid hardcoding secrets.`,
	},
};

const CODE_GENERATOR_TYPES_FINAL = {
	// Add Playwright Page (TypeScript) generator prompt
	PLAYWRIGHT_PAGE_TS: {
		name: 'Playwright Page (TypeScript)',
		prompt: `You are a code generator for Playwright using TypeScript. Generate code that uses Playwright's Page object and async/await.
- Use TypeScript types (import { Page } from '@playwright/test' or from 'playwright' as appropriate).
- Provide an exported async function like: export async function run(page: Page) { /* steps */ }
- Use page.goto, page.locator(...).click(), page.locator(...).fill(), and await where necessary.
- Prefer locator over page.$ selectors, and use await page.waitForLoadState('networkidle') or appropriate waits when needed.
- Keep code concise, include necessary imports, and avoid wrapping in unnecessary classes.
- If the user prompt references selectors or credentials, inject them as variables or parameters and avoid hardcoding secrets.`,
	},
};

const CODE_GENERATOR_TYPES_ALL = {
	// Add Playwright Page (TypeScript) generator prompt
	PLAYWRIGHT_PAGE_TS: {
		name: 'Playwright Page (TypeScript)',
		prompt: `You are a code generator for Playwright using TypeScript. Generate code that uses Playwright's Page object and async/await.
- Use TypeScript types (import { Page } from '@playwright/test' or from 'playwright' as appropriate).
- Provide an exported async function like: export async function run(page: Page) { /* steps */ }
- Use page.goto, page.locator(...).click(), page.locator(...).fill(), and await where necessary.
- Prefer locator over page.$ selectors, and use await page.waitForLoadState('networkidle') or appropriate waits when needed.
- Keep code concise, include necessary imports, and avoid wrapping in unnecessary classes.
- If the user prompt references selectors or credentials, inject them as variables or parameters and avoid hardcoding secrets.`,
	},
};

const CODE_GENERATOR_TYPES_FINAL_ALL = {
	// Add Playwright Page (TypeScript) generator prompt
	PLAYWRIGHT_PAGE_TS: {
		name: 'Playwright Page (TypeScript)',
		prompt: `You are a code generator for Playwright using TypeScript. Generate code that uses Playwright's Page object and async/await.
- Use TypeScript types (import { Page } from '@playwright/test' or from 'playwright' as appropriate).
- Provide an exported async function like: export async function run(page: Page) { /* steps */ }
- Use page.goto, page.locator(...).click(), page.locator(...).fill(), and await where necessary.
- Prefer locator over page.$ selectors, and use await page.waitForLoadState('networkidle') or appropriate waits when needed.
- Keep code concise, include necessary imports, and avoid wrapping in unnecessary classes.
- If the user prompt references selectors or credentials, inject them as variables or parameters and avoid hardcoding secrets.`,
	},
};